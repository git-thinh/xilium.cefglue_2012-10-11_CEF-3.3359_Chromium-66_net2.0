﻿namespace Xilium.CefGlue.Interop
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    internal static partial class NativeMethods
    {
        public const int CW_USEDEFAULT = unchecked((int)0x80000000);
    }
}
