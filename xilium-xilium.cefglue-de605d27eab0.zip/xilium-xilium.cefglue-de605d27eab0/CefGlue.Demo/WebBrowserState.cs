﻿namespace Xilium.CefGlue.Demo
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    public sealed class WebBrowserState
    {
        public string Title { get; set; }
        public string Address { get; set; }
        public string TargetUrl { get; set; }
    }
}
